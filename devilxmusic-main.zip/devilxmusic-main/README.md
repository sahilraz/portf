<h2 align="center">
    「 Shahil 」</h2>

<p align="center">
  <img src="https://github.com/ShahilxMusic/blob/main/Shahilali5.gif">
</p>
</p>
 <h3></h3>
 <h3 align="center">

    
ᴀᴠᴀɪʟᴀʙʟᴇ ᴏɴ ᴛᴇʟᴇɢʀᴀᴍ ᴀs 

[˹мꝛ Shahil˼](https://t.me/Shahilali5)

<h3 align="center">
<a href="https://github.com/Shahilali5"><img alt="Website" src="https://img.shields.io/badge/𝕮𝖍𝖆𝖒𝖕𝖚-red"></a>

[![Telegram](https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white)](https://telegram.me/TheShivanshu)
[![Instagram](https://img.shields.io/badge/-Instagram-E1306C?style=for-the-badge&logo=instagram&logoColor=white)](https://www.instagram.com/Shivanshu_deo)
[![Snapchat](https://img.shields.io/badge/-Snapchat-F5AD09?style=for-the-badge&logo=snapchat&logoColor=white)](https://www.snapchat.com/add/TERROR-2.o?share_id=0SMI0ikB1E4&locale=en-IN)
[![Gmail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](https://telegra.ph/%EA%9C%B1n%CE%B9%CE%BD%CE%B1i%D1%95n%CF%85-12-02)
[![Youtube](https://img.shields.io/badge/-YouTube-F50909?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/@itsmechampu)



<h3 align="center">
<a href="https://www.youtube.com/@TERROR-2.O"><img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"></a>  
</a></p>
<p align="center">
<a href="https://github.com/Shahilali5/ShahilxMusic"><img src="https://img.shields.io/github/stars/Shahilali5/ShahilxMusic?color=black&logo=github&logoColor=black&style=for-the-badge" alt="Stars" /></a>
<a href="https://github.com/Shahilali5/ShahilxMusic/network/members"> <img src="https://img.shields.io/github/forks/Shahilali5/ShahilxMusic?color=black&logo=github&logoColor=black&style=for-the-badge" /></a>
<a href="https://github.com/Shahilali5/ShahilxMusic/blob/master/LICENSE"> <img src="https://img.shields.io/badge/License-MIT-blueviolet?style=for-the-badge" alt="License" /> </a>
<a href="https://www.python.org/"> <img src="https://img.shields.io/badge/Written%20in-Python-skyblue?style=for-the-badge&logo=python" alt="Python" /> </a>
<a href="https://pypi.org/project/Telethon/"> <img src="https://img.shields.io/pypi/v/telethon?color=white&label=telethon&logo=python&logoColor=blue&style=for-the-badge" /></a>
<a href="https://pypi.org/project/Pyrogram/"> <img src="https://img.shields.io/pypi/v/pyrogram?color=white&label=pyrogram&logo=python&logoColor=blue&style=for-the-badge" /></a>
<a href="https://github.com/Shahilali5/ShahilxMusic/commits/"> <img src="https://img.shields.io/github/last-commit/Shahilali5/ShahilxMusic?color=black&logo=github&logoColor=black&style=for-the-badge" /></a></p>
<a href="https://www.youtube.com/@TERROR-2.o"><img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"></a>  
<p align="center">
  <img src="https://github.com/Shahilali5/ShahilxMusic/blob/main/%F0%9F%96%A4%EA%9C%B1%E2%83%9F%D0%BD%CD%A5%CE%B9%CE%BD%CD%A3%CE%B1%CD%AB%D0%B8%D1%95%D0%BD%CF%85%F0%9F%96%A4.gif">
</p>


<h4>𝐓ʀʏ 𝐌ʏ 𝐓ᴇʟᴇɢʀᴀᴍ 𝐁ᴏᴛ's<h4>
 
[![MUSIC](https://img.shields.io/badge/-Shahilali5Bot-E1306C?style=for-the-badge&logo=Shahilali5Bot&logoColor=green)](https://t.me/Shahilali5Bot)
[![MUSIC](https://img.shields.io/badge/TheKittyXD_Bot-%2307405e.svg?&style=for-the-badge&logo=TheKittyXD_Bot&logoColor)](https://t.me/TheKittyXD_Bot)
[![MUSIC](https://img.shields.io/badge/itsWaifuBot-%2307405e.svg?&style=for-the-badge&logo=itsWaifuBot&logoColor)](https://t.me/itsWaifuBot)


<b>𝗗𝗘𝗣𝗟𝗢𝗬𝗠𝗘𝗡𝗧 𝗠𝗘𝗧𝗛𝗢𝗗𝗦</b>
</p>

<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ᴠᴘs 」─
</h3>

<details>
<summary><b>𝐕𝐏𝐒</b></summary>
<br>

Copy these blue words on by on from here to use commands in you own vps.
</h3>

```console
sudo apt-get update && sudo apt-get upgrade -y
```
```console
sudo apt-get install python3-pip ffmpeg -y
```
```console
sudo pip3 install -U pip
```
```console
curl -fssL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt-get install nodejs -y && npm i -g npm
```
```console
git clone https://github.com/Shahilali5/ShahilxMusic &&  cd ShahilxMusic
```
```console
pip3 install -U -r requirements.txt
```
```console
cp sample.env .env
```
```console
vi .env
```
➤Edit .env with your vars 

</h3>

➤Setup will install each and every requirement, nodejs and pip packages automatically. After successfull installation of requirements , setup will ask you to input your vars.

</h3>

➤Please input your vars correctly.

```console
bash start
```
When you see any error after bash start then use this command and again try bash start.👇

```console
sudo pkill -9 python3
```
</details>

<h3 align="center">
    ─「 ᴅᴇᴩʟᴏʏ ᴏɴ ʜᴇʀᴏᴋᴜ 」─
</h3>
 
<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/Shahilali5/ShahilxMusic"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>


<h3 align="center">
       ─「 𝗦𝗥𝗧𝗜𝗡𝗚 𝗦𝗘𝗦𝗦𝗜𝗢𝗡  」─
</h3>

<h3 align="center">
<a href="https://www.youtube.com/@TERROR-2.o"><img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"></a>  



<h3 align="center">
    ─「 🖤Shahil🖤 」─
</h3>

<p align="center">
<a href="https://telegram.me/Shahilali5"><img src="https://img.shields.io/badge/-Owner-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

<h3 align="center">
    ─「 sᴜᴩᴩᴏʀᴛ 」─
</h3>

<p align="center">
<a href="https://telegram.me/ShahilBotsList"><img src="https://img.shields.io/badge/-Support%20Channel-blue.svg?style=for-the-badge&logo=Telegram"></a>
</p>

<h3 align="center">
<a href="https://www.youtube.com/@TERROR-2.o"><img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"></a>             
<h3 align="center">
ɪғ ʏᴏᴜ ᴄᴀɴ ᴄʀʏ ғᴏʀ ᴍᴇ...        <h3 align="center">
     ᴛʀᴜsᴛ ᴍᴇ ɪ ᴄᴀɴ ᴅɪᴇ ғᴏʀ ᴜʜʜ!!
     <h3 align="center">
<a href="https://www.youtube.com/@TERROR-2.o"><img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif"></a>  


<h1>  ᴄᴜʀʀᴇɴᴛʟʏ ᴏɴ sᴘᴏᴛɪғʏ </h1>

[<img src="https://novatorem.visualbean.vercel.app/api/spotify" alt="𝕮𝖍𝖆𝖒𝖕𝖚 Spotify" width="75%" />](https://open.spotify.com/user/bc1q3pdfrefej8zvml5697dnwuhg9kqgskz5062t23?si=hVSKCshlR3WUDi8qXBKyXw&utm_source=copy-link)

<h3 align="center">ᴍᴇᴇᴛ ᴏᴜʀ ᴄᴏɴᴛʀɪʙᴜᴛᴏʀs</h3>
<p align="center" style="box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2); padding: 10px; border-radius: 8px;">
  <a href="https://github.com/Shahilali5/ShahilxMusic/graphs/contributors">
    <img src="https://contrib.rocks/image?repo=Shahilali5/ShahilxMusic" alt="Contributors" style="border: 2px solid #000; border-radius: 10px;"/>
  </a>
</p>

